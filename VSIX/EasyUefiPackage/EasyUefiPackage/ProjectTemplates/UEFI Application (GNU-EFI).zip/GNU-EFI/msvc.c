// error LNK2001: unresolved external symbol _fltused
int _fltused = 0;